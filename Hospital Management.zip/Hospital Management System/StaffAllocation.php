<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Staff Allocation</title>
</head>
<div align="center">
<body bgcolor="#1c69af">
	<?php include('Include/Header.html'); ?>
    <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="POST">
      <fieldset>
       <link rel="stylesheet" href="Style.css">
      	<legend>Staff Allocation</legend>
      	Staff Name:<input type="text" name="staffname" placeholder="Staff Name">
      	<br><br>
      	Paitent Name:<input type="text" name="paitentname" placeholder="Paitent Name">
      	<br><br>
      	<input type="submit" name="submit">
      </form>
      	<?php
     if($_SERVER['REQUEST_METHOD'] === "POST")
     {
        $staffName = $_POST['staffname'];
        $paitentName = $_POST['paitentname'];
       
       if(!file_exists("StaffAllocationData.json"))
     {
        $handle1 = fopen("StaffAllocationData.json", "a");
        $arr1 = array('staffname' => $staffName, 'paitentname' => $paitentName);
        $encode = json_encode($arr1);
        $res = fwrite($handle1, $encode . "\n");
        if($res)
        {
            echo "Allocation Successfull";
        }
        else
        {
            echo "Error Please Try Again";
        }
      } 
     }
             
    ?>

      </fieldset>
  </div>
      <?php include('Include/Footer.html'); ?>
</body>
</html>