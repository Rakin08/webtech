<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Delete Paitent</title>
	<link rel="stylesheet" href="Style.css">
</head>
<div align="center">
<body bgcolor="#1c69af">
   <?php include('Include/Header.html'); ?>
      <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
	<fieldset>
		<legend>Delete Paitent</legend>
		<h1>User List</h1>
		<h3 align="center">ID:<input type="int" placeholder="id"></h3>
		<h3 align="center">Username:<input type="text" placeholder="username"></h3>
      <input type="submit" name="Delete" value="Delete">
	</fieldset>
</div>
<?php include('Include/Footer.html'); ?>
</body>
</html>