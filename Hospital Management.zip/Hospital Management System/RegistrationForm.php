<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Registration Form</title>
</head>
<body bgcolor="#1c69af">
    <div align="center">
   <?php include('Include/Header.html'); ?>
      <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="POST">
    <h1>DOCTOR</h1>
    <fieldset>
        <link rel="stylesheet" href="Style.css">
        <legend>Registration Form</legend>
        First Name:<input type="text" name="firstname" placeholder="First Name" required="firstname">
        <br><br>
        Last Name:<input type="text" name="lastname" placeholder="Last Name" required="lastname">
        <br><br>
        Password:<input type="Password" name="password"placeholder="Password" required="password">
        <br><br>
        Username:<input type="text" name="username" placeholder="username" required="username">
        <br><br>
        Date of Birth:<input type="date" name="DOB" required="DOB">
        <br><br>                
        Address:<input type="textarea" name="address" placeholder="Address"required="Address">
        <br><br>
        Phone no:<input type="number" name="number" placeholder="Number" required="Number">
        <br><br>  
        <input type="submit" name="submit" value="submit"> 
    </form> 
    <?php
     if($_SERVER['REQUEST_METHOD'] === "POST")
     {
        $firstName = $_POST['firstname'];
        $lastName = $_POST['lastname'];
        $Password = $_POST['password'];
        $userName = $_POST['username'];
        $DoB = $_POST['DOB'];
        $Address = $_POST['address'];
        $Number = $_POST['number'];

        if(!file_exists("DoctorData.json"))
     {
        $handle1 = fopen("DoctorData.json", "a");
        $arr1 = array('firstname' => $firstName, 'lastname' => $lastName, 'password' => $Password, 'username' => $userName, 'DOB' => $DoB, 'address' => $Address, 'number' => $Number);
        $encode = json_encode($arr1);
        $res = fwrite($handle1, $encode . "\n");
        if($res)
        {
            echo "Registration Successfull";
        }
        else
        {
            echo "Error Please Try Again";
        }
        } 
        else echo "Okay";
      }
             
    ?>
        
 </fieldset>
</form></div>
 <?php include('Include/Footer.html'); ?> 
</body>
</html>