<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Discount</title>
      <link rel="stylesheet" href="Style.css">
</head>
<div align="center">
<body bgcolor="#1c69af">
   <?php include('Include/Header.html'); ?>
      <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="POST">
	<fieldset>
		<legend>Discount</legend>
		<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
		Main Amount:<input type="number" name="mainamount" placeholder="Main Amount">
		<br><br>
		Discount Amount:<input type="number" name="disamount"placeholder="Discount Amount">
		<br><br>
		New Amount:<input type="number" name="newamount"placeholder="New Amount">
		<br><br>
		<input type="submit" name="submit">
	</form>
	<?php
	if($_SERVER['REQUEST_METHOD'] === "POST"){
     $mainAmount = $_POST['mainamount'];
     $disAmount = $_POST['disamount'];
     $newAmount = $_POST['newamount'];

     if(empty($mainAmount) || empty($disAmount) || empty($newAmount)){
     	echo "Please fillup the amount";
     }
     else{
        if($_SERVER['REQUEST_METHOD'] === "POST")
     {
        $mainAmount = $_POST['mainamount'];
        $disAmount = $_POST['disamount'];
        $newAmount = $_POST['newamount'];
       
       if(!file_exists("DiscountData.json"))
     {
        $handle1 = fopen("DiscountData.json", "a");
        $arr1 = array('mainamount' => $mainAmount, 'disamount' => $disAmount, 'newamount' => $newAmount);
        $encode = json_encode($arr1);
        $res = fwrite($handle1, $encode . "\n");
        if($res)
        {
            echo "Successfull";
        }
        else
        {
            echo "Error Please Try Again";
        }
      } 
     }
     }
    } 
    
	?>
	</fieldset>
</div>
            <?php include('Include/Footer.html'); ?>


</body>
</html