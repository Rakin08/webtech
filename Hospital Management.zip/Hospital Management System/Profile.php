<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Profile</title>
</head>
<div align="center">
<body bgcolor="#1c69af">
	    <?php include('Include/Header.html'); ?>
	    	<h5 align="center">  Visit us at: House #16, Road #2
		    <br>
          Dhanmondi R/A,Dhaka-1205</h5>
	<fieldset>
		<link rel="stylesheet" href="Style.css">
		<legend>Profile</legend>
		<fieldset>
		<ul>
	    <li><a href="Settings.php">Setting</a></li>
	    <li><a href="Logout.php">Log out</a></li>
	    </ul>
	    </fieldset>
	  </legend>
		<legend>
			<fieldset>
			<ul>

				<li><a href="AddPaitent.php">Add Paitent</a></li>
				<li><a href="Discount.php">Give Discount</a></li>
				<li><a href="PaitentInformation.php">Paitent information</a></li>
				<li><a href="StaffAllocation.php">Staff allocation</a></li>
				<li><a href="ContactAdmin.php">Contact Admin</a></li>
			</ul>
			</fieldset>
		</legend>
	</fieldset>
</div>
		    <?php include('Include/Footer.html'); ?>


</body>
</html>