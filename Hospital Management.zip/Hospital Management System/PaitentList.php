<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Paitent List</title>
</head>
<div align="center">
<body bgcolor="#1c69af">
   <?php include('Include/Header.html'); ?>
      <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
	<?php include('Include/Header.html'); ?>

	<fieldset>
		   <link rel="stylesheet" href="Style.css">
		<legend>Paitent List</legend>
		<h1> List</h1>
	</fieldset>
</div>
	    <?php include('Include/Footer.html'); ?>


</body>
</html>