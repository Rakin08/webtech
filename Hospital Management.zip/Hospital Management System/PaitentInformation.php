<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Paitent Information</title>
	<link rel="stylesheet" href="Style.css">
</head>
<div align="center">
<body bgcolor="#1c69af">
	    <?php include('Include/Header.html'); ?>
	    <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
	    <fieldset>
		<legend>Paitent Information</legend>
	<ul>
		<li><a href="EditPaitent.php">Edit Paitent</a></li>
		<br><br>
		<li><a href="DeletePaitent.php">Delete Paitent</a></li>
		<br><br>
		<li><a href="PaitentList.php">View Paitent</a></li>
		<br><br>       
	</ul>
	</fieldset>
    </div>
	    <?php include('Include/Footer.html'); ?>


</body>
</html>