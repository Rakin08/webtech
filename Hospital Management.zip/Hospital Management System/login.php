<?php 
	session_start();

	if(count($_SESSION) != 0){

		header("Location: Profile.php");
	}
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>log in</title>
	<link rel="stylesheet" href="Style.css">
	<?php include('Include/Header.html');  ?>
	<h5 align="center">  Visit us at: House #16, Road #2
		    <br>
          Dhanmondi R/A,Dhaka-1205</h5>			
</head>
<div align="center">
<body bgcolor="#1c69af">
	<form action="Profile.php" method="get">
	<fieldset>
		<legend>LOG IN</legend>
		<h3>Username:<input type="text" placeholder="username"></h3>
		<h3 >Password:<input type="Password" placeholder="password">
		</h3>
		<input type="submit" name="Login" value="Login">
</form>
<?php  
if(isset($_POST["submit"])){  
  
if(!empty($_POST['username']) && !empty($_POST['password'])) {  
    $user=$_POST['username'];  
    $pass=$_POST['password'];  
  
    $con=mysql_connect('localhost','root','') or die(mysql_error());  
    mysql_select_db('user_registration') or die("cannot select DB");  
  
    $query=mysql_query("SELECT * FROM user WHERE username='".$username."' AND password='".$password."'");  
    $numrows=mysql_num_rows($query);  
    if($numrows!=0)  
    {  
    while($row=mysql_fetch_assoc($query))  
    {  
    $dbusername=$row['username'];  
    $dbpassword=$row['password'];  
    }  
  
    if($user == $dbusername && $pass == $dbpassword)  
    {  
    session_start();  
    $_SESSION['sess_user']=$user;  
  
    /* Redirect browser */  
    header("Location: member.php");  
    }  
    } else {  
    echo "Invalid username or password!";  
    }  
  
} else {  
    echo "All fields are required!";  
}  
}  
?> 
</fieldset>
</div> 
<?php include('Include/Footer.html'); ?>

</body>
</html>
