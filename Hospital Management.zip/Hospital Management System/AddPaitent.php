<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Add Paitent</title>
</head>
<div align="center">
<body bgcolor="#1c69af">
   <?php include('Include/Header.html'); ?>
      <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="POST">
	<fieldset>
   <link rel="stylesheet" href="Style.css">
	<legend>Add Paitent</legend>
		Name:<input type="text" name="username" placeholder="username">
		<br><br>
		Disease:<input type="text" name="disease" placeholder="Disease">
		<br><br>
		Room:<input type="Number" name="room" placeholder="Room no">
		<br><br>
		Bed:<input type="Number" name="bed" placeholder="Bed no">
		<br><br>
		<input type="submit" name="submit">
	</form>
</div>
<?php
if($_SERVER['REQUEST_METHOD'] === "POST"){
     $Name = $_POST['name'];
     $Disease = $_POST['disease'];
     $Room = $_POST['room'];
     $Bed = $_POST['bed'];

     if(empty($Name) || empty($Disease) || empty($Room) || empty($Bed))
     {
     	echo "Please fillup the amount";
     }
     else{
        if($_SERVER['REQUEST_METHOD'] === "POST")
     {
        $Name = $_POST['name'];
        $Disease = $_POST['disease'];
        $Room = $_POST['room'];
        $Bed = $_POST['bed'];
       
       if(!file_exists("PaitentData.json"))
     {
        $handle1 = fopen("PaitentData.json", "a");
        $arr1 = array('name' => $Name, 'disease' => $Disease, 'room' => $Room, 'bed' => $Bed);
        $encode = json_encode($arr1);
        $res = fwrite($handle1, $encode . "\n");
        if($res)
        {
            echo "Paitent Added Successfull";
        }
        else
        {
            echo "Error Please Try Again";
        }
      } 
     }
     }
    } 
    
	?>
</fieldset>
<?php include('Include/Footer.html'); ?>

</body>
</html>