<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Edit Paitent</title>
	<link rel="stylesheet" href="Style.css">
</head>
<div align="center">
<body bgcolor="#1c69af">
    <?php include('Include/Header.html'); ?>
    <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="POST">
	<fieldset>
		<legend>Edit Paitent</legend>
		Name:<input type="text" placeholder="Name">
		<br><br>
		Disease:<input type="text" placeholder="Disease">
		<br><br>
		Room:<input type="Number" placeholder="Room no">
		<br><br>
		Bed:<input type="Number" placeholder="Bed no">
		<br><br>
		<input type="submit" name="submit">
	</fieldset>
</div>
    <?php include('Include/Footer.html'); ?>


</body>
</html>