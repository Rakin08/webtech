<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Contact Admin</title>
</head>
<div align="center">
<body bgcolor="#1c69af">
   <?php include('Include/Header.html'); ?>
      <h5 align="center">  Visit us at: House #16, Road #2
          <br>
          Dhanmondi R/A,Dhaka-1205</h5>
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF'])?>" method="POST">
	<fieldset>
   <link rel="stylesheet" href="Style.css">
		<legend>Contact Admin</legend>
		Message Admin:<input type="textarea" name="contactadmin"placeholder="Message">
		<br><br>
		Username<input type="text" name="username" placeholder="username"required="username">
		<input type="submit" name="submit">
		<?php
     if($_SERVER['REQUEST_METHOD'] === "POST")
     {
        $contactAdmin = $_POST['contactadmin'];
        $userName = $_POST['username'];
       
       if(!file_exists("ContactAdmin.json"))
     {
        $handle1 = fopen("ContactAdmin.json", "a");
        $arr1 = array('contactadmin' => $contactAdmin, 'username' => $userName);
        $encode = json_encode($arr1);
        $res = fwrite($handle1, $encode . "\n");
        if($res)
        {
            echo "Successfull";
        }
        else
        {
            echo "Error Please Try Again";
        }
      } 
     }
             
    ?>
	</fieldset>
      </div>

<?php include('Include/Footer.html'); ?>
</body>
</html>