function isValid(AddPaitent){
	const username = AddPaitent.username.value;
	const password = AddPaitent.Disease.value;
	const password = AddPaitent.Room.value;
	const password = AddPaitent.Bed.value;



	if(username === "" || Disease === "" || Room === "" || Bed === ""){

		if(username === ""){

			document.getElementById("errorMsgUser").innerHTML = "Please provide username!";
		}
		else{
			document.getElementById("errorMsgUser").innerHTML = "";
		}

		if(Disease === ""){

			document.getElementById("errorMsgPass").innerHTML = "Please provide Password!";
		}
		else{
			document.getElementById("errorMsgPass").innerHTML = "";
		}
		if(Room === ""){

			document.getElementById("errorMsgPass").innerHTML = "Please provide Room!";
		}
		else{
			document.getElementById("errorMsgPass").innerHTML = "";
		}
        if(Bed === ""){

			document.getElementById("errorMsgPass").innerHTML = "Please provide Bed!";
		}
		else{
			document.getElementById("errorMsgPass").innerHTML = "";
		}


		return false;
	}
else{
	return true;
}