function isValid(DeletePaitent){
	const ID = DeletePaitent.ID.value;
	const username = DeletePaitent.username.value;

	if(ID === "" || username === ""){

		if(ID === ""){

			document.getElementById("errorMsgUser").innerHTML = "Please provide ID!";
		}
		else{
			document.getElementById("errorMsgUser").innerHTML = "";
		}

		if(username === ""){

			document.getElementById("errorMsgPass").innerHTML = "Please provide username!";
		}
		else{
			document.getElementById("errorMsgPass").innerHTML = "";
		}

		return false;
	}
else{
	return true;
}