function isValid(ContactAdmin){
	const username = ContactAdmin.username.value;
	const password = ContactAdmin.Disease.value;


	if(text === "" || username === ""){

		if(text === ""){

			document.getElementById("errorMsgUser").innerHTML = "Please provide text!";
		}
		else{
			document.getElementById("errorMsgUser").innerHTML = "";
		}

		if(username === ""){

			document.getElementById("errorMsgPass").innerHTML = "Please provide username!";
		}
		else{
			document.getElementById("errorMsgPass").innerHTML = "";
		}

		return false;
	}
else{
	return true;
}